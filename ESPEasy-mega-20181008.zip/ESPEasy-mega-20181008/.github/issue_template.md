### If you self compile, please state this and PLEASE try to ONLY REPORT ISSUES WITH OFFICIAL BUILDS! ###
<!--- If you self compile, please state this and PLEASE try to ONLY REPORT ISSUES WITH OFFICIAL BUILDS!  --->
<!--- NOTE: This is not a support forum! For questions and support go here: --->
<!--- https://www.letscontrolit.com/forum/viewforum.php?f=1 --->
<!--- Remove topics that are not applicable to your feature request of issue --->
<!--- Remember to have a "to the point" TITLE --->

### Summarize of the problem/feature request
<!--- Describe the problem or feature request --->
YOUR TEXT GOES HERE

### Expected behavior
<!--- Tell us what should happen? --->
YOUR TEXT GOES HERE

### Actual behavior
<!--- Tell us what happens instead? --->
YOUR TEXT GOES HERE

### Steps to reproduce
<!--- How can we trigger this problem? --->
1. 
2. 
3. 

<!--- Does the problem persists after powering off and on? (just resetting isn't enough sometimes) --->
<!--- Please document if you have restarted the unit and if the problem is then gone etc. etc. --->
### System configuration
<!--- Please add as much information and screenshots as possible  --->
Hardware:

<!--- You should also provide links to hardware pages etc where we can find more info  --->
<!--- If you self compile, please state this and PLEASE try to ONLY REPORT ISSUES WITH OFFICIAL BUILDS!  --->
ESP Easy version: 

<!--- In order to have a better readablity of your issue then you should place screenshots here  --->
<!--- Simply drag and drop them onto this template, move the text string below the "ESP Easy settings/screenshots" topic  --->
ESP Easy settings/screenshots: 

### Rules or log data
<!--- place your code/rules between the two ``` rows  --->
<!--- remove if not applicable!  --->
```

```
