// Copyright 2017 David Conran
#include "IRrecv.h"
#include "IRrecv_test.h"
#include "IRsend.h"
#include "IRsend_test.h"
#include "ir_Toshiba.h"
#include "gtest/gtest.h"

// Tests for Toshiba A/C methods.

// Test sending typical data only.
TEST(TestSendToshibaAC, SendDataOnly) {
  IRsendTest irsend(4);
  irsend.begin();

  uint8_t toshiba_code[TOSHIBA_AC_STATE_LENGTH] = {
      0xF2, 0x0D, 0x03, 0xFC, 0x01, 0x00, 0x00, 0x00, 0x00};
  irsend.reset();
  irsend.sendToshibaAC(toshiba_code);
  EXPECT_EQ(
      "m4400s4300"
      "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
      "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s7048"
      "m4400s4300"
      "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
      "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s7048", irsend.outputStr());
}

// Test sending with repeats.
TEST(TestSendToshibaAC, SendWithRepeats) {
  IRsendTest irsend(4);
  irsend.begin();

  irsend.reset();
  uint8_t toshiba_code[TOSHIBA_AC_STATE_LENGTH] = {
      0xF2, 0x0D, 0x03, 0xFC, 0x01, 0x00, 0x00, 0x00, 0x00};

  irsend.sendToshibaAC(toshiba_code, TOSHIBA_AC_STATE_LENGTH, 0);
  EXPECT_EQ(
    "m4400s4300"
    "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
    "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
    "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s7048", irsend.outputStr());

  irsend.reset();
  irsend.sendToshibaAC(toshiba_code, TOSHIBA_AC_STATE_LENGTH, 2);
  EXPECT_EQ(
    "m4400s4300"
    "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
    "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
    "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s7048"
    "m4400s4300"
    "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
    "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
    "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s7048"
    "m4400s4300"
    "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
    "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
    "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
    "m543s7048", irsend.outputStr());
}

// Test sending atypical sizes.
TEST(TestSendToshibaAC, SendUnexpectedSizes) {
  IRsendTest irsend(4);
  irsend.begin();

  uint8_t toshiba_short_code[8] = {0x01, 0x02, 0x03, 0x04,
                                   0x05, 0x06, 0x07, 0x08};
  uint8_t toshiba_long_code[10] = {0x01, 0x02, 0x03, 0x04, 0x05,
                                   0x06, 0x07, 0x08, 0x09, 0x0A};
  irsend.reset();
  irsend.sendToshibaAC(toshiba_short_code, TOSHIBA_AC_STATE_LENGTH - 1);
  ASSERT_EQ("", irsend.outputStr());

  irsend.reset();
  irsend.sendToshibaAC(toshiba_long_code, TOSHIBA_AC_STATE_LENGTH + 1);
  ASSERT_EQ(
      "m4400s4300"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s1623m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s1623m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623m543s1623"
      "m543s472m543s472m543s472m543s472m543s1623m543s472m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s1623m543s472m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s1623m543s472m543s1623m543s472"
      "m543s7048"
      "m4400s4300"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s1623m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s1623m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623m543s1623"
      "m543s472m543s472m543s472m543s472m543s1623m543s472m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s1623m543s472m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s1623m543s472m543s1623m543s472"
      "m543s7048", irsend.outputStr());
}

// Tests for IRToshibaAC class.

TEST(TestToshibaACClass, Power) {
  IRToshibaAC toshiba(0);
  toshiba.begin();

  toshiba.on();
  EXPECT_TRUE(toshiba.getPower());

  toshiba.off();
  EXPECT_FALSE(toshiba.getPower());

  toshiba.setPower(true);
  EXPECT_TRUE(toshiba.getPower());

  toshiba.setPower(false);
  EXPECT_FALSE(toshiba.getPower());
}

TEST(TestToshibaACClass, Temperature) {
  IRToshibaAC toshiba(0);
  toshiba.begin();

  toshiba.setTemp(0);
  EXPECT_EQ(TOSHIBA_AC_MIN_TEMP, toshiba.getTemp());

  toshiba.setTemp(255);
  EXPECT_EQ(TOSHIBA_AC_MAX_TEMP, toshiba.getTemp());

  toshiba.setTemp(TOSHIBA_AC_MIN_TEMP);
  EXPECT_EQ(TOSHIBA_AC_MIN_TEMP, toshiba.getTemp());

  toshiba.setTemp(TOSHIBA_AC_MAX_TEMP);
  EXPECT_EQ(TOSHIBA_AC_MAX_TEMP, toshiba.getTemp());

  toshiba.setTemp(TOSHIBA_AC_MIN_TEMP - 1);
  EXPECT_EQ(TOSHIBA_AC_MIN_TEMP, toshiba.getTemp());

  toshiba.setTemp(TOSHIBA_AC_MAX_TEMP + 1);
  EXPECT_EQ(TOSHIBA_AC_MAX_TEMP, toshiba.getTemp());

  toshiba.setTemp(17);
  EXPECT_EQ(17, toshiba.getTemp());

  toshiba.setTemp(21);
  EXPECT_EQ(21, toshiba.getTemp());

  toshiba.setTemp(25);
  EXPECT_EQ(25, toshiba.getTemp());

  toshiba.setTemp(30);
  EXPECT_EQ(30, toshiba.getTemp());
}

TEST(TestToshibaACClass, OperatingMode) {
  IRToshibaAC toshiba(0);
  toshiba.begin();

  toshiba.setMode(TOSHIBA_AC_AUTO);
  EXPECT_EQ(TOSHIBA_AC_AUTO, toshiba.getMode());

  toshiba.setMode(TOSHIBA_AC_COOL);
  EXPECT_EQ(TOSHIBA_AC_COOL, toshiba.getMode());

  toshiba.setMode(TOSHIBA_AC_HEAT);
  EXPECT_EQ(TOSHIBA_AC_HEAT, toshiba.getMode());

  toshiba.setMode(TOSHIBA_AC_DRY);
  EXPECT_EQ(TOSHIBA_AC_DRY, toshiba.getMode());

  toshiba.setMode(TOSHIBA_AC_HEAT + 1);
  EXPECT_EQ(TOSHIBA_AC_AUTO, toshiba.getMode());

  toshiba.setMode(255);
  EXPECT_EQ(TOSHIBA_AC_AUTO, toshiba.getMode());

  // Setting the power off changes the underlying mode in the state to heat.
  toshiba.setPower(true);
  toshiba.setMode(TOSHIBA_AC_COOL);
  EXPECT_EQ(TOSHIBA_AC_COOL, toshiba.getMode());
  EXPECT_EQ(TOSHIBA_AC_COOL, toshiba.getMode(true));
  toshiba.setPower(false);
  EXPECT_EQ(TOSHIBA_AC_COOL, toshiba.getMode());
  EXPECT_EQ(TOSHIBA_AC_HEAT, toshiba.getMode(true));
}

TEST(TestToshibaACClass, FanSpeed) {
  IRToshibaAC toshiba(0);
  toshiba.begin();

  toshiba.setFan(TOSHIBA_AC_FAN_AUTO);
  EXPECT_EQ(TOSHIBA_AC_FAN_AUTO, toshiba.getFan());

  toshiba.setFan(255);
  EXPECT_EQ(TOSHIBA_AC_FAN_MAX, toshiba.getFan());

  toshiba.setFan(TOSHIBA_AC_FAN_MAX);
  EXPECT_EQ(TOSHIBA_AC_FAN_MAX, toshiba.getFan());

  toshiba.setFan(TOSHIBA_AC_FAN_MAX - 1);
  EXPECT_EQ(TOSHIBA_AC_FAN_MAX - 1, toshiba.getFan());

  toshiba.setFan(1);
  EXPECT_EQ(1, toshiba.getFan());

  toshiba.setFan(2);
  EXPECT_EQ(2, toshiba.getFan());

  toshiba.setFan(3);
  EXPECT_EQ(3, toshiba.getFan());

  toshiba.setFan(4);
  EXPECT_EQ(4, toshiba.getFan());

  toshiba.setFan(TOSHIBA_AC_FAN_MAX + 1);
  EXPECT_EQ(TOSHIBA_AC_FAN_MAX, toshiba.getFan());
}

TEST(TestToshibaACClass, RawState) {
  IRToshibaAC toshiba(0);
  toshiba.begin();

  uint8_t initial_state[TOSHIBA_AC_STATE_LENGTH] = {
      0xF2, 0x0D, 0x03, 0xFC, 0x01, 0x00, 0x00, 0x00, 0x01};
  uint8_t modified_state[TOSHIBA_AC_STATE_LENGTH] = {
      0xF2, 0x0D, 0x03, 0xFC, 0x01, 0x00, 0xC1, 0x00, 0xC0};

  // Verify the starting state.
  EXPECT_STATE_EQ(initial_state, toshiba.getRaw(), TOSHIBA_AC_BITS);
  EXPECT_TRUE(toshiba.getPower());
  EXPECT_EQ(TOSHIBA_AC_AUTO, toshiba.getMode());
  EXPECT_EQ(TOSHIBA_AC_FAN_AUTO, toshiba.getFan());

  // Change some settings.
  toshiba.setMode(TOSHIBA_AC_COOL);
  toshiba.setFan(TOSHIBA_AC_FAN_MAX);
  toshiba.setTemp(TOSHIBA_AC_MIN_TEMP);
  // Verify those were set.
  EXPECT_EQ(TOSHIBA_AC_COOL, toshiba.getMode());
  EXPECT_EQ(TOSHIBA_AC_FAN_MAX, toshiba.getFan());
  EXPECT_EQ(TOSHIBA_AC_MIN_TEMP, toshiba.getTemp());
  // Retrieve the modified state.
  EXPECT_STATE_EQ(modified_state, toshiba.getRaw(), TOSHIBA_AC_BITS);

  // Set it back to the initial state.
  toshiba.setRaw(initial_state);

  // Check the new state was set correctly.
  EXPECT_TRUE(toshiba.getPower());
  EXPECT_EQ(TOSHIBA_AC_AUTO, toshiba.getMode());
  EXPECT_EQ(TOSHIBA_AC_FAN_AUTO, toshiba.getFan());
  EXPECT_STATE_EQ(initial_state, toshiba.getRaw(), TOSHIBA_AC_BITS);
}

TEST(TestToshibaACClass, Checksums) {
  IRToshibaAC toshiba(0);
  toshiba.begin();

  uint8_t initial_state[TOSHIBA_AC_STATE_LENGTH] = {
      0xF2, 0x0D, 0x03, 0xFC, 0x01, 0x00, 0x00, 0x00, 0x01};
  uint8_t modified_state[TOSHIBA_AC_STATE_LENGTH] = {
      0xF2, 0x0D, 0x03, 0xFC, 0x01, 0x00, 0xC1, 0x00, 0xC0};
  uint8_t invalid_state[TOSHIBA_AC_STATE_LENGTH] = {
      0xF2, 0x0D, 0x03, 0xFC, 0x01, 0x00, 0x00, 0x00, 0x00};

  EXPECT_EQ(0x01, toshiba.calcChecksum(initial_state));
  EXPECT_EQ(0xC0, toshiba.calcChecksum(modified_state));
  // Check we can call it without instantiating the object.
  EXPECT_EQ(0x01, IRToshibaAC::calcChecksum(initial_state));
  // Use different lengths.
  EXPECT_EQ(0x01, IRToshibaAC::calcChecksum(initial_state,
                                            TOSHIBA_AC_STATE_LENGTH - 1));
  EXPECT_EQ(0xFF, IRToshibaAC::calcChecksum(initial_state, 3));
  // Minimum length that actually means anything.
  EXPECT_EQ(0xF2, IRToshibaAC::calcChecksum(initial_state, 2));
  // Technically, there is no such thing as a checksum for a length of < 2
  // But test it anyway
  EXPECT_EQ(0x00, IRToshibaAC::calcChecksum(initial_state, 1));
  EXPECT_EQ(0x00, IRToshibaAC::calcChecksum(initial_state, 0));

  // Validity tests.
  EXPECT_TRUE(IRToshibaAC::validChecksum(initial_state));
  EXPECT_TRUE(IRToshibaAC::validChecksum(modified_state));
  EXPECT_FALSE(IRToshibaAC::validChecksum(invalid_state));
  EXPECT_FALSE(IRToshibaAC::validChecksum(initial_state, 0));
  EXPECT_FALSE(IRToshibaAC::validChecksum(initial_state, 1));
  EXPECT_FALSE(IRToshibaAC::validChecksum(initial_state, 2));
}

TEST(TestToshibaACClass, HumanReadableOutput) {
  IRToshibaAC toshiba(0);
  toshiba.begin();

  uint8_t initial_state[TOSHIBA_AC_STATE_LENGTH] = {
      0xF2, 0x0D, 0x03, 0xFC, 0x01, 0x00, 0x00, 0x00, 0x01};
  uint8_t modified_state[TOSHIBA_AC_STATE_LENGTH] = {
      0xF2, 0x0D, 0x03, 0xFC, 0x01, 0x00, 0xC1, 0x00, 0xC0};

  toshiba.setRaw(initial_state);
  EXPECT_EQ("Power: On, Mode: 0 (AUTO), Temp: 17C, Fan: 0 (AUTO)",
            toshiba.toString());
  toshiba.setRaw(modified_state);
  EXPECT_EQ("Power: On, Mode: 1 (COOL), Temp: 17C, Fan: 5 (MAX)",
            toshiba.toString());
  toshiba.off();
  toshiba.setTemp(25);
  toshiba.setFan(3);
  toshiba.setMode(TOSHIBA_AC_DRY);
  EXPECT_EQ("Power: Off, Mode: 2 (DRY), Temp: 25C, Fan: 3",
            toshiba.toString());
}

TEST(TestToshibaACClass, MessageConstuction) {
  IRToshibaAC toshiba(0);
  IRsendTest irsend(4);
  toshiba.begin();
  irsend.begin();

  toshiba.setFan(1);
  toshiba.setMode(TOSHIBA_AC_COOL);
  toshiba.setTemp(27);
  toshiba.on();

  // Check everything for kicks.
  EXPECT_EQ(1, toshiba.getFan());
  EXPECT_EQ(TOSHIBA_AC_COOL, toshiba.getMode());
  EXPECT_EQ(27, toshiba.getTemp());
  EXPECT_TRUE(toshiba.getPower());

  irsend.reset();
  irsend.sendToshibaAC(toshiba.getRaw());
  EXPECT_EQ(
      "m4400s4300"
      "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
      "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s1623m543s472m543s1623m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s1623m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s1623m543s1623m543s1623m543s472m543s472m543s472m543s472m543s472"
      "m543s7048"
      "m4400s4300"
      "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
      "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s1623m543s472m543s1623m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s1623m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s1623m543s1623m543s1623m543s472m543s472m543s472m543s472m543s472"
      "m543s7048", irsend.outputStr());

  // Turn off the power and re-check.
  toshiba.setPower(false);
  // Check everything for kicks.
  EXPECT_EQ(1, toshiba.getFan());
  EXPECT_EQ(TOSHIBA_AC_COOL, toshiba.getMode());
  EXPECT_EQ(27, toshiba.getTemp());
  EXPECT_FALSE(toshiba.getPower());

  irsend.reset();
  irsend.sendToshibaAC(toshiba.getRaw());
  EXPECT_EQ(
      "m4400s4300"
      "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
      "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s1623m543s472m543s1623m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s1623m543s472m543s472m543s472m543s1623m543s1623m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s1623m543s472"
      "m543s7048"
      "m4400s4300"
      "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
      "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s1623m543s472m543s1623m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s1623m543s472m543s472m543s472m543s1623m543s1623m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s1623m543s472"
      "m543s7048", irsend.outputStr());

  // Turn the power back on, and check nothing changed.
  toshiba.on();

  EXPECT_EQ(1, toshiba.getFan());
  EXPECT_EQ(TOSHIBA_AC_COOL, toshiba.getMode());
  EXPECT_EQ(27, toshiba.getTemp());
  EXPECT_TRUE(toshiba.getPower());

  irsend.reset();
  irsend.sendToshibaAC(toshiba.getRaw());
  EXPECT_EQ(
      "m4400s4300"
      "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
      "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s1623m543s472m543s1623m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s1623m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s1623m543s1623m543s1623m543s472m543s472m543s472m543s472m543s472"
      "m543s7048"
      "m4400s4300"
      "m543s1623m543s1623m543s1623m543s1623m543s472m543s472m543s1623m543s472"
      "m543s472m543s472m543s472m543s472m543s1623m543s1623m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s1623m543s1623"
      "m543s1623m543s1623m543s1623m543s1623m543s1623m543s1623m543s472m543s472"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s1623m543s472m543s1623m543s472m543s472m543s472m543s472m543s472"
      "m543s472m543s1623m543s472m543s472m543s472m543s472m543s472m543s1623"
      "m543s472m543s472m543s472m543s472m543s472m543s472m543s472m543s472"
      "m543s1623m543s1623m543s1623m543s472m543s472m543s472m543s472m543s472"
      "m543s7048", irsend.outputStr());
}

// Decoding a message we entirely constructed based solely on a given state.
TEST(TestDecodeToshibaAC, SyntheticExample) {
  IRsendTest irsend(4);
  IRrecv irrecv(4);
  irsend.begin();

  uint8_t expectedState[TOSHIBA_AC_STATE_LENGTH] = {
      0xF2, 0x0D, 0x03, 0xFC, 0x01, 0x00, 0x00, 0x00, 0x01};

  irsend.reset();
  irsend.sendToshibaAC(expectedState);
  irsend.makeDecodeResult();
  EXPECT_TRUE(irrecv.decode(&irsend.capture));
  ASSERT_EQ(TOSHIBA_AC, irsend.capture.decode_type);
  ASSERT_EQ(TOSHIBA_AC_BITS, irsend.capture.bits);
  EXPECT_STATE_EQ(expectedState, irsend.capture.state, irsend.capture.bits);
}

// Test decoding against captures from a real Toshiba A/C remote.
// Recorded by @mwildbolz
TEST(TestDecodeToshibaAC, RealExamples) {
  IRToshibaAC toshiba(0);
  IRsendTest irsend(4);
  IRrecv irrecv(4);
  irsend.begin();

  uint16_t rawData1[295] = {
      4442, 4292, 612, 1544,  616, 1544,  616, 1544,  612, 1548,  610, 468,
      612, 468,  662, 1494,  640, 438,  616, 464,  614, 464,  616, 464,
      612, 468,  610, 1544,  616, 1544,  616, 468,  612, 1544,  616, 464,
      694, 386,  616, 464,  612, 468,  612, 468,  636, 444,  610, 1546,
      616, 1544,  612, 1546,  614, 1546,  616, 1546,  740, 1420,  612, 1544,
      616, 1546,  616, 464,  610, 468,  610, 470,  612, 468,  610, 468,  610,
      470,  636, 438,  616, 464,  616, 464,  616, 1546,  636, 442,  612, 1546,
      614, 1544,  616, 464,  614, 464,  610, 468,  612, 468,  612, 468,
      612, 468,  636, 440,  614, 464,  616, 464,  616, 464,  612, 468,
      636, 442,  638, 442,  662, 418,  610, 464,  616, 464,  616, 464,
      610, 468,  612, 468,  636, 444,  610, 468,  638, 438,  614, 1546,
      612, 1548,  612, 470,  610, 468,  636, 442,  612, 468,  612, 1544,
      612, 7396,  4442, 4292,  610, 1546,  616, 1544,  612, 1548,  612, 1546,
      616, 464,  616, 464,  616, 1544,  612, 468,  662, 418,  610, 468,
      638, 442,  638, 438,  616, 1546,  616, 1544,  612, 468,  610, 1546,
      616, 464,  616, 464,  642, 438,  616, 464,  612, 468,  610, 470,
      610, 1546,  616, 1544,  612, 1546,  616, 1546,  614, 1546,  612, 1550,
      610, 1544,  616, 1546,  614, 464,  642, 438,  610, 468,  612, 468,
      612, 468,  612, 468,  610, 468,  638, 438,  614, 464,  616, 1544,
      636, 444,  636, 1520,  616, 1544,  616, 464,  616, 464,  612, 468,
      612, 468,  612, 468,  612, 468,  612, 464,  612, 470,  636, 442,
      638, 442,  612, 470,  692, 384,  614, 464,  616, 464,  612, 468,
      610, 468,  612, 468,  610, 470,  610, 464,  616, 464,  616, 464,
      616, 464,  610, 1550,  610, 1546,  640, 444,  688, 386,  616, 464,
      612, 468,  612, 1544,  642};

  irsend.reset();
  irsend.sendRaw(rawData1, 295, 38000);
  irsend.makeDecodeResult();
  EXPECT_TRUE(irrecv.decode(&irsend.capture));
  ASSERT_EQ(TOSHIBA_AC, irsend.capture.decode_type);
  ASSERT_EQ(TOSHIBA_AC_BITS, irsend.capture.bits);
  toshiba.setRaw(irsend.capture.state);
  EXPECT_TRUE(toshiba.getPower());
  EXPECT_EQ(23, toshiba.getTemp());
  EXPECT_EQ(TOSHIBA_AC_FAN_AUTO, toshiba.getFan());
  EXPECT_EQ(TOSHIBA_AC_AUTO, toshiba.getMode());

  uint16_t rawData2[295] = {
      4500, 4236,  636, 1520,  642, 1520,  640, 1520,  664, 1492,  642, 440,
      668, 412,  642, 1518,  638, 438,  666, 414,  640, 438,  642, 438,
      638, 442,  642, 1516,  640, 1520,  642, 438,  642, 1520,  636, 438,
      668, 412,  640, 440,  666, 412,  642, 438,  668, 412,  640, 1516,
      668, 1492,  642, 1520,  666, 1494,  638, 1520,  642, 1520,  668, 1490,
      666, 1494,  642, 438,  638, 438,  668, 412,  668, 412,  642, 438,
      642, 438,  664, 412,  642, 438,  642, 438,  642, 1518,  642, 434,
      668, 412,  642, 438,  668, 412,  692, 388,  666, 412,  642, 434,
      642, 438,  642, 1518,  668, 412,  668, 412,  640, 438,  638, 438,
      642, 438,  640, 438,  668, 1492,  642, 440,  666, 412,  640, 438,
      642, 438,  642, 434,  668, 412,  668, 412,  666, 414,  666, 1494,
      640, 438,  642, 434,  668, 412,  642, 438,  642, 438,  668, 412,
      668, 414,  640, 7362,  4474, 4262,  642, 1518,  638, 1520,  640, 1520,
      668, 1494,  640, 434,  642, 438,  640, 1520,  642, 438,  642, 438,
      642, 438,  642, 438,  642, 434,  668, 1494,  642, 1518,  638, 442,
      638, 1520,  642, 438,  642, 438,  668, 414,  664, 408,  642, 438,
      668, 412,  642, 1520,  666, 1494,  642, 1514,  642, 1518,  642, 1520,
      636, 1520,  668, 1494,  666, 1494,  638, 438,  666, 414,  640, 440,
      666, 412,  668, 412,  668, 412,  642, 434,  668, 412,  668, 412,
      668, 1494,  642, 438,  642, 434,  642, 438,  642, 438,  642, 438,
      642, 438,  642, 434,  646, 434,  642, 1518,  668, 412,  642, 438,
      642, 434,  666, 414,  640, 438,  642, 438,  642, 1518,  642, 438,
      642, 434,  668, 412,  642, 438,  642, 438,  642, 438,  642, 438,
      642, 438,  640, 1520,  636, 438,  642, 438,  642, 438,  666, 414,
      668, 412,  642, 440,  640, 438,  640};

  irsend.reset();
  irsend.sendRaw(rawData2, 295, 38000);
  irsend.makeDecodeResult();
  EXPECT_TRUE(irrecv.decode(&irsend.capture));
  ASSERT_EQ(TOSHIBA_AC, irsend.capture.decode_type);
  ASSERT_EQ(TOSHIBA_AC_BITS, irsend.capture.bits);
  toshiba.setRaw(irsend.capture.state);
  EXPECT_TRUE(toshiba.getPower());
  EXPECT_EQ(17, toshiba.getTemp());
  EXPECT_EQ(3, toshiba.getFan());
  EXPECT_EQ(TOSHIBA_AC_COOL, toshiba.getMode());

  uint16_t rawData3[295] = {
      4474, 4262,  642, 1514,  642, 1520,  642, 1520,  642, 1514,
      642, 438,  642, 438,  642, 1520,  636, 438,  642, 438,  642, 438,
      642, 438,  642, 438,  640, 1520,  638, 1520,  642, 438,  640, 1520,
      642, 438,  642, 434,  642, 438,  642, 438,  642, 438,  668, 414,
      636, 1520,  642, 1520,  642, 1514,  642, 1520,  642, 1520,  640, 1518,
      638, 1520,  666, 1494,  642, 438,  642, 434,  642, 438,  640, 438,
      642, 438,  642, 440,  640, 434,  642, 438,  642, 438,  642, 1520,
      642, 438,  642, 1514,  642, 1520,  640, 1520,  636, 438,  642, 438,
      642, 438,  666, 414,  642, 1520,  636, 1520,  642, 438,  642, 438,
      640, 438,  642, 434,  642, 1518,  642, 1520,  642, 438,  642, 434,
      640, 438,  642, 438,  642, 438,  642, 440,  642, 438,  668, 408,
      642, 1520,  642, 438,  642, 1520,  638, 1518,  642, 438,  642, 438,
      640, 1520,  640, 438,  642, 7362,  4474, 4262,  642, 1518,  638, 1520,
      640, 1520,  642, 1520,  638, 438,  642, 438,  642, 1518,  642, 438,
      638, 438,  642, 438,  642, 438,  642, 438,  642, 1514,  642, 1520,
      642, 438,  666, 1490,  642, 438,  642, 438,  642, 440,  640, 438,
      642, 434,  640, 438,  642, 1520,  642, 1520,  636, 1520,  642, 1520,
      642, 1514,  642, 1518,  642, 1518,  640, 1516,  642, 438,  642, 438,
      642, 438,  640, 438,  638, 442,  642, 434,  642, 440,  640, 438,
      642, 438,  642, 1518,  642, 438,  642, 1514,  642, 1520,  642, 1518,
      642, 438,  642, 432,  642, 438,  642, 438,  642, 1520,  642, 1514,
      642, 438,  642, 438,  642, 438,  642, 438,  642, 1514,  642, 1520,
      642, 438,  642, 438,  638, 438,  642, 438,  642, 438,  640, 440,
      642, 438,  640, 434,  642, 1520,  642, 438,  640, 1520,  668, 1490,
      666, 414,  640, 438,  642, 1520,  642, 438,  636};

  irsend.reset();
  irsend.sendRaw(rawData3, 295, 38000);
  irsend.makeDecodeResult();
  EXPECT_TRUE(irrecv.decode(&irsend.capture));
  ASSERT_EQ(TOSHIBA_AC, irsend.capture.decode_type);
  ASSERT_EQ(TOSHIBA_AC_BITS, irsend.capture.bits);
  toshiba.setRaw(irsend.capture.state);
  EXPECT_TRUE(toshiba.getPower());
  EXPECT_EQ(24, toshiba.getTemp());
  EXPECT_EQ(TOSHIBA_AC_FAN_MAX, toshiba.getFan());
  EXPECT_EQ(TOSHIBA_AC_HEAT, toshiba.getMode());

  uint16_t rawData4[295] = {
      4474, 4262,  636, 1520,  640, 1520,  640, 1520,  638, 1518,  642, 438,
      642, 438,  642, 1520,  636, 438,  642, 438,  642, 438,  642, 438,
      636, 444,  636, 1520,  640, 1520,  642, 438,  638, 1524,  638, 438,
      640, 438,  642, 438,  640, 438,  642, 438,  638, 438,  642, 1518,
      642, 1520,  666, 1494,  636, 1520,  640, 1520,  640, 1520,  636, 1524,
      638, 1520,  640, 440,  640, 438,  642, 438,  636, 444,  636, 438,
      642, 438,  640, 440,  640, 438,  642, 438,  642, 1518,  638, 438,
      642, 1518,  642, 438,  640, 1520,  636, 444,  636, 438,  640, 438,
      642, 438,  668, 1494,  640, 438,  642, 1518,  636, 444,  636, 438,
      640, 1520,  642, 1518,  642, 1520,  636, 444,  636, 438,  642, 438,
      642, 438,  640, 440,  640, 438,  640, 440,  640, 438,  640, 1518,
      642, 1520,  636, 1524,  636, 1518,  642, 438,  642, 1518,  642, 1518,
      640, 438,  642, 7364,  4472, 4262,  642, 1518,  642, 1518,  638, 1518,
      642, 1520,  642, 438,  642, 438,  640, 1520,  636, 440,  640, 438,
      642, 438,  640, 438,  642, 438,  642, 1518,  636, 1524,  636, 438,
      640, 1520,  642, 438,  642, 438,  640, 438,  636, 444,  636, 438,
      668, 412,  642, 1518,  642, 1520,  642, 1520,  636, 1518,  642, 1518,
      642, 1520,  636, 1520,  668, 1494,  642, 438,  636, 444,  664, 412,
      642, 438,  668, 412,  642, 438,  636, 442,  638, 442,  638, 438,
      642, 1518,  642, 438,  642, 1518,  638, 438,  642, 1518,  642, 440,
      640, 438,  636, 444,  636, 444,  636, 1520,  642, 438,  642, 1520,
      636, 444,  636, 438,  642, 1520,  640, 1520,  636, 1520,  668, 412,
      642, 438,  642, 438,  642, 438,  638, 442,  636, 438,  642, 438,
      668, 412,  640, 1520,  638, 1524,  636, 1520,  642, 1520,  636, 444,
      638, 1522,  638, 1518,  640, 438,  642};

      irsend.reset();
      irsend.sendRaw(rawData4, 295, 38000);
      irsend.makeDecodeResult();
      EXPECT_TRUE(irrecv.decode(&irsend.capture));
      ASSERT_EQ(TOSHIBA_AC, irsend.capture.decode_type);
      ASSERT_EQ(TOSHIBA_AC_BITS, irsend.capture.bits);
      toshiba.setRaw(irsend.capture.state);
      EXPECT_FALSE(toshiba.getPower());
      EXPECT_EQ(22, toshiba.getTemp());
      EXPECT_EQ(4, toshiba.getFan());

      // Confirming the quirky behaviour that the 'Power OFF' signal
      // sets the mode to heat.
      // The previous state the remote was in was 'AUTO' just prior to
      // sending the power off message.
      EXPECT_EQ(TOSHIBA_AC_HEAT, toshiba.getMode());
}
